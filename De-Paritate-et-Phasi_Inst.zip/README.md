# De Paritate et Phasi

Classical SystemaDock essay synthesizing the supplied handwritten *Numerical Analysis* note and the applied essay *From Parity to Phase*.

## Build

```bash
latexmk -lualatex -interaction=nonstopmode -file-line-error -outdir=build main.tex
```

The main driver loads `sections/_manifest.tex` through `ForPagesScan*`. The title and abstract are loaded separately so the scanner excludes them from the body.

## Outputs

- `build/De-Paritate-et-Phasi.pdf`: compiled essay
- `exports/De-Paritate-et-Phasi_Inst.zip`: portable editable source project
