local root = arg[1] or "sections"
local output = arg[2] or (root .. "/_manifest.tex")
local p = io.popen("find " .. string.format("%q", root) .. " -type f -name '*.tex' | sort")
if not p then os.exit(1) end
local files = {}
for path in p:lines() do
  if not path:match("/_manifest%.tex$") and not path:match("/010%-title%-and%-abstract%.tex$") then
    table.insert(files, path:gsub("\\", "/"))
  end
end
p:close()
local tmp = output .. ".tmp"
local f = assert(io.open(tmp, "w"))
f:write("% Generated deterministically by forpages_scan.lua\n")
for _, path in ipairs(files) do f:write("\\input{" .. path .. "}\n") end
f:close()
assert(os.rename(tmp, output))
